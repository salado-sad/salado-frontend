// src/pages/Admin/AdminPanel.js
import React, { useState } from "react";
import './AdminPanel.css';
import PackageList from "../../components/PackageList";
import AddPackage from "../../components/AddPackage";

import basketIcon from "../../assets/basket-icon.svg";
import plusIcon from "../../assets/plus-icon.svg";
import settingsIcon from "../../assets/settings-icon.svg";
import bellIcon from "../../assets/bell-icon.svg";
import searchIcon from "../../assets/search-icon.svg";
import logo from "../../assets/logo_mono.png";

const AdminPanel = () => {
  const [activePage, setActivePage] = useState("packages");

  // Add initial state for packages
  const [packages, setPackages] = useState([
    {
      name: 'Agha Farid',
      price: '$800.85',
      description: 'Bache khoobie. Aziatesh nakonin. Bayad khordesh',
      image: 'https://media.licdn.com/dms/image/v2/D4D03AQHP1k_GASXLmQ/profile-displayphoto-shrink_400_400/0/1720623177822?e=1744243200&v=beta&t=ZMqV6ju4Zd6YfWp99lt40uwCUs9SA_vvCoxp1ldfMNA',
      products: [
        {
          name: 'Strawberry',
          quantity: 5,
          image: 'https://cdn.nyallergy.com/wp-content/uploads/square-1432664914-strawberry-facts1-1200x900.jpeg'
        },
        {
          name: 'Spinach',
          quantity: 3,
          image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTEFIf1LwpQrKWxz9lSfn976uLBL9n5g18CUQ&s'
        }
      ]
    }
    // Additional packages can be added here if needed
  ]);

  const handleAddPackage = (newPackage) => {
    setPackages((prevPackages) => [...prevPackages, newPackage]);
  };

  const renderContent = () => {
    switch (activePage) {
      case "packages":
        return <PackageList packages={packages} />;
      case "add":
        return <AddPackage onAddPackage={handleAddPackage} />;
      default:
        return <div>Welcome, Admin. Select an option from the menu.</div>;
    }
  };

  return (
    <div className="admin-panel-container">
      <div className="sidebar">
        <button className="sidebar-icon">
          <img src={logo} alt="Logo" />
        </button>
        <button className={`sidebar-icon ${activePage === "search" ? "active" : ""}`} onClick={() => setActivePage("search")}>
          <img src={searchIcon} alt="Search" />
        </button>
        <button className={`sidebar-icon ${activePage === "packages" ? "active" : ""}`} onClick={() => setActivePage("packages")}>
          <img src={basketIcon} alt="Packages" />
        </button>
        <button className={`sidebar-icon ${activePage === "add" ? "active" : ""}`} onClick={() => setActivePage("add")}>
          <img src={plusIcon} alt="Add" />
        </button>
        <button className={`sidebar-icon ${activePage === "settings" ? "active" : ""}`} onClick={() => setActivePage("settings")}>
          <img src={settingsIcon} alt="Settings" />
        </button>
      </div>

      <main className="main-content">
        <div className="header">
          <div>
            <h2>Welcome, Admin</h2>
            <p>Mon, 30 Dec 2024</p>
          </div>
          <div className="notifications">
            <img src={bellIcon} alt="Notifications" />
          </div>
        </div>
        <div className="content">
          {renderContent()}
        </div>
      </main>
    </div>
  );
};

export default AdminPanel;